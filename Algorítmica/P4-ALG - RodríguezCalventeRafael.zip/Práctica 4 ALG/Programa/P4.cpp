#include <stdlib.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cassert>
#include <string>
#include <fstream>
#include <chrono>

using namespace std;
using namespace std::chrono;

high_resolution_clock::time_point t_before, t_after;
duration<double> time_duration;

int **getMatriz(int n);
void backtracking (int commensals, int level, int commensal, int &c_local, int solution[], vector<bool> &seated_commensals, int **matrix, int final_solution[]);
int ActualValue(int commensals, int solution[], vector<bool> &seated_commensals, int **matrix);


int c_global_max = 0;


int main(int argc, char const *argv[]){

	if(argc != 2){
		cerr << "Error en el numero de argumentos." << endl;
		exit(1);
	}

	int n = atoi(argv[1]);
	int c_local = 0, res[n], final_res[n], **matriz = getMatriz(n);
	vector<bool> seated_commensals(n, false);

	t_before = high_resolution_clock::now();
	backtracking(n, 1, 0, c_local, res, seated_commensals, matriz, final_res);
	t_after = high_resolution_clock::now();

    time_duration = duration_cast<duration<double>>(t_after - t_before);

	cout <<  n << " "<< time_duration.count() << endl;

	return 0;

}


int **getMatriz(int n){

	srand(time(NULL));
	int **matriz;
	matriz = new int*[n-1];

	for (int i = 0; i < n; i++)
		matriz[i] = new int[n-1];

	for (int i = 0; i < n ;i++)
		for (int j = i; j < n; j++){
			if (i==j)
				matriz[i][j] = 0;
			else{
				//Con este "else" conseguimos que las conveniencias de los comensales de las posiciones i,j y j,i sean exactamente las mismas.
				int num = ( rand() % (100) );
				matriz[i][j] = num;
				matriz[j][i] = num;
			}
		}

	return matriz;
	
}

void backtracking (int commensals, int level, int commensal, int &c_local, int solution[], vector<bool> &seated_commensals, int **matrix, int final_solution[]) {

	c_local = 0;
	seated_commensals[commensal] = true;
	solution[level - 1] = commensal;
	
	for (int next_commensal = 0; next_commensal < commensals; next_commensal++) { //Este bucle se encargará de recorrer todos y cada uno de los comensales.
		if (seated_commensals[next_commensal] == false) { //Entra si el comensal no está sentado
			c_local = ActualValue(commensals, solution, seated_commensals, matrix);
			backtracking(commensals, level + 1, next_commensal, c_local, solution, seated_commensals, matrix, final_solution);
			if (level == (commensals - 1)) { //En el caso de que estemos en un nodo hoja, entra en este "if".
				c_local = ActualValue(commensals, solution, seated_commensals, matrix);
				//Si hemos obtenido una cota mayor, guardamos esta nueva.
				if (c_local > c_global_max) {
					for(int i = 0; i < commensals; i++)
						final_solution[i] = solution[i];
					c_global_max = c_local;
				}
			}else{ //En el caso de que no estemos en un nodo hora, entra en este "else"
				c_local = ActualValue(commensals, solution, seated_commensals, matrix);
			}
			seated_commensals[next_commensal] = false; //El comensal deja de estar sentado
		}
	}
}

int ActualValue(int commensals, int solution[], vector<bool> &seated_commensals, int **matrix){

	vector<int> i_seated_commensals;
	int value = 0;

	for(int i = 0; i < commensals; i++){
		if(seated_commensals[i] == true){ //En el caso de que el comensal esté sentado, entramos en el "if"
			int j = 0;
			while(j < commensals){
				if(solution[j] == i)
					i_seated_commensals.push_back(j);
				j++;
			}
		}
	}

	for(int i = 1; i < i_seated_commensals.size(); i++)
		value += matrix[i_seated_commensals[i-1]][i_seated_commensals[i]];
	
	if(i_seated_commensals.size() > 2)
		value += matrix[0][i_seated_commensals.back()]; 

	return (value * 2); //Tenemos que tener en cuenta tanto el comensal de la izquierda como el de la derecha, por esa razón multiplicamos por 2.

}
