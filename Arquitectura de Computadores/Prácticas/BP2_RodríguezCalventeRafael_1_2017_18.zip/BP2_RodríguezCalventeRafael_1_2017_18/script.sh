#!/bin/bash

	
		time ./pmv-OpenMP-b 100
		time ./pmv-OpenMP-a 100
		time ./pmv-OpenMP-reduction 100

		time ./pmv-OpenMP-b 1000
		time ./pmv-OpenMP-a 1000
		time ./pmv-OpenMP-reduction 1000

		time ./pmv-OpenMP-b 10000
		time ./pmv-OpenMP-a 10000
		time ./pmv-OpenMP-reduction 10000




